
import sys
sys.path.insert(0, '../../Utilities/')

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.interpolate import griddata
from pyDOE import lhs
from plotting import newfig, savefig
from mpl_toolkits.mplot3d import Axes3D
import time
import matplotlib.gridspec as gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable

np.random.seed(1234)
tf.set_random_seed(1234)


class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X, u, v, layers, lb, ub):

        self.lb = lb
        self.ub = ub

        self.x = X[:, 0:1]
        self.t = X[:, 1:2]


        self.u = u
        self.v = v

        # Initialize NNs
        self.layers = layers
        self.weights, self.biases = self.initialize_NN(layers)

        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))

        self.lambda_1 = tf.Variable([0.5], dtype=tf.float32)
        self.lambda_2 = tf.Variable([0.5], dtype=tf.float32)


        # tf Placeholders
        self.x_tf = tf.placeholder(tf.float32, shape=[None, self.x.shape[1]])
        self.t_tf = tf.placeholder(tf.float32, shape=[None, self.t.shape[1]])

        self.u_tf = tf.placeholder(tf.float32, shape=[None, self.u.shape[1]])
        self.v_tf = tf.placeholder(tf.float32, shape=[None, self.v.shape[1]])



        # tf Graphs
        self.u_pred, self.v_pred, _, _ = self.net_uv(self.x_tf, self.t_tf)
        self.f_u_pred, self.f_v_pred = self.net_f_uv(self.x_tf, self.t_tf)

        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))
        # Loss
        self.loss = 10 * tf.reduce_mean(tf.square(self.u_tf - self.u_pred)) + \
                    10 * tf.reduce_mean(tf.square(self.v_tf - self.v_pred)) + \
                    tf.reduce_mean(tf.square(self.f_u_pred)) + \
                    tf.reduce_mean(tf.square(self.f_v_pred))
                    #tf.reduce_mean(tf.square(self.lambda_1 - 0.001)) + \
                    #tf.reduce_mean(tf.square(self.lambda_2 - 0.03))


        # Optimizers
        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss,
                                                                method='L-BFGS-B',
                                                                options={'maxiter': 80000,
                                                                         'maxfun': 80000,
                                                                         'maxcor': 80,
                                                                         'maxls': 80,
                                                                         'ftol': 1.0 * np.finfo(float).eps})

        self.optimizer_Adam = tf.train.AdamOptimizer()
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)


        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))

        init = tf.global_variables_initializer()
        self.sess.run(init)

    def initialize_NN(self, layers):
        weights = []
        biases = []
        num_layers = len(layers)
        for l in range(0, num_layers - 1):
            W = self.xavier_init(size=[layers[l], layers[l + 1]])
            b = tf.Variable(tf.zeros([1, layers[l + 1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W)
            biases.append(b)
        return weights, biases

    def xavier_init(self, size):
        in_dim = size[0]
        out_dim = size[1]
        xavier_stddev = np.sqrt(2 / (in_dim + out_dim))
        return tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)

    def neural_net(self, X, weights, biases):
        num_layers = len(weights) + 1

        H = 2.0 * (X - self.lb) / (self.ub - self.lb) - 1.0
        for l in range(0, num_layers - 2):
            W = weights[l]
            b = biases[l]
            linear = tf.add(tf.matmul(H, W), b)
            # 应用Swish激活函数 f(x) = x * sigmoid(x)
            H = tf.multiply(linear, tf.nn.sigmoid(linear))
        W = weights[-1]
        b = biases[-1]
        Y = tf.add(tf.matmul(H, W), b)
        return Y

    def net_uv(self, x, t):

        X = tf.concat([x, t], 1)

        uv = self.neural_net(X, self.weights, self.biases)
        u = uv[:, 0:1]
        v = uv[:, 1:2]

        p = np.flip(u)
        q = np.flip(v)

        return u, v, p, q

    def net_f_uv(self, x, t):

        lambda_1 = self.lambda_1
        lambda_2 = self.lambda_2


        u, v, p, q = self.net_uv(x, t)

        u_t = tf.gradients(u, t)[0]
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]

        v_t = tf.gradients(v, t)[0]
        v_x = tf.gradients(v, x)[0]
        v_xx = tf.gradients(v_x, x)[0]
        p_x = tf.gradients(p, x)[0]
        q_x = tf.gradients(q, x)[0]

        g = -1
        dtx = 3 * (lambda_2 * lambda_2) * g * (1 / tf.math.cosh(x)) ** 2
        stx = 2 * lambda_1 * x

        VX = -2 * (1 / tf.math.cosh(x)) ** 2 - dtx * (lambda_1 * tf.cos(stx) - tf.tanh(x) * tf.sin(stx))
        WX = -2 * lambda_1 * tf.tanh(x) - dtx * (lambda_1 * tf.sin(stx) + tf.tanh(x) * tf.cos(stx))

        f_u = u_t + v_xx - VX * v - WX * u + 2 * g * u * u_x * p - 2 * g * v_x * v * p + 2 * g * q * u * v_x + 2 * g * q * u_x * v + \
              g * p_x * (u ** 2) - g * p_x * (v ** 2) + 2 * g * q_x * u * v

        f_v = u_xx - v_t - VX * u + WX * v + g * p * u_x * v - g * p * u * u_x + g * q * u * u_x - g * q * v_x * v - 2 * g * u * v * p_x + \
              g * q_x * (u ** 2) - g * q_x * (v ** 2)

        return f_u, f_v

    def callback(self, loss, lambda_1, lambda_2):
        print('Loss: %e, l1: %.5f , l2: %.5f' % (loss, lambda_1, lambda_2))

    def train(self, nIter):

        tf_dict = {self.x_tf: self.x, self.t_tf: self.t, self.u_tf: self.u, self.v_tf: self.v}

        start_time = time.time()
        for it in range(nIter):
            self.sess.run(self.train_op_Adam, tf_dict)

            # Print
            if it % 10 == 0:
                elapsed = time.time() - start_time
                loss_value = self.sess.run(self.loss, tf_dict)
                lambda_1_value = self.sess.run(self.lambda_1)
                lambda_2_value = self.sess.run(self.lambda_2)
                print('It: %d, Loss: %.3e, Lambda_1: %.6f, Lambda_2: %.6f, Time: %.2f' %
                      (it, loss_value, lambda_1_value, lambda_2_value, elapsed))
                start_time = time.time()

        self.optimizer.minimize(self.sess,
                                feed_dict = tf_dict,
                                fetches = [self.loss, self.lambda_1, self.lambda_2],
                                loss_callback = self.callback)

    def predict(self, X_star):

        tf_dict = {self.x_tf: X_star[:, 0:1], self.t_tf: X_star[:, 1:2]}

        u_star = self.sess.run(self.u_pred, tf_dict)
        v_star = self.sess.run(self.v_pred, tf_dict)


        f_u_star = self.sess.run(self.f_u_pred, tf_dict)
        f_v_star = self.sess.run(self.f_v_pred, tf_dict)

        return u_star, v_star, f_u_star, f_v_star


if __name__ == "__main__":


    N_u = 20000
    layers = [2, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,  2]

    data = scipy.io.loadmat('D:\\PINNs-master\\main\\Data\\feijuyu2.mat')
    t = data['tdata'].flatten()[:, None]
    x = data['x'].flatten()[:, None]
    Exact = data['udata']
    Exact_u = np.real(Exact)
    Exact_v = np.imag(Exact)
    Exact_h = np.sqrt(Exact_u ** 2 + Exact_v ** 2)

    X, T = np.meshgrid(x, t)

    X_star = np.hstack((X.flatten()[:, None], T.flatten()[:, None]))
    u_star = Exact_u.T.flatten()[:, None]
    v_star = Exact_v.T.flatten()[:, None]
    h_star = Exact_h.T.flatten()[:, None]

    # Doman bounds
    lb = np.array([-16.0, 0.0])
    ub = np.array([16.0, 2.0])
    ########################### noisy data ############################
    noise = 0.0

    idx = np.random.choice(X_star.shape[0], N_u, replace=False)
    X_u_train = X_star[idx, :]
    u_train = u_star[idx, :]
    v_train = v_star[idx, :]

    model = PhysicsInformedNN(X_u_train, u_train, v_train, layers, lb, ub)

    start_time = time.time()
    # model.train(43200)
    # elapsed = time.time() - start_time
    # print('Training time: %.4f' % (elapsed))
    #
    #
    # u_pred, v_pred, f_u_pred, f_v_pred = model.predict(X_star)
    # h_pred = np.sqrt(u_pred ** 2 + v_pred ** 2)
    #
    # error_u = np.linalg.norm(u_star - u_pred, 2) / np.linalg.norm(u_star, 2)
    # error_v = np.linalg.norm(v_star - v_pred, 2) / np.linalg.norm(v_star, 2)
    # error_h = np.linalg.norm(h_star - h_pred, 2) / np.linalg.norm(h_star, 2)
    #
    #
    #
    # lambda_1_value = model.sess.run(model.lambda_1)
    # lambda_2_value = model.sess.run(model.lambda_2)
    #
    #
    # error_lambda_1 = np.abs(lambda_1_value - 0.001)/0.001 * 100
    # error_lambda_2 = np.abs(lambda_2_value - 0.03)/0.03 * 100
    #
    # print('Error u: %e' % (error_u))
    # print('Error v: %e' % (error_v))
    # print('Error h: %e' % (error_h))
    # print('Error l1: %.5f%%' %(error_lambda_1))
    # print('Error l2: %.5f%%' %(error_lambda_2))

    # U_pred = griddata(X_star, u_pred.flatten(), (X, T), method='cubic')
    # V_pred = griddata(X_star, v_pred.flatten(), (X, T), method='cubic')
    # H_pred = griddata(X_star, h_pred.flatten(), (X, T), method='cubic')
    #
    # FU_pred = griddata(X_star, f_u_pred.flatten(), (X, T), method='cubic')
    # FV_pred = griddata(X_star, f_v_pred.flatten(), (X, T), method='cubic')
    ######################################################################
    ############################# Noisy data ###############################

    noise = 0.01
    u = u_train + noise * np.std(u_train) * np.random.randn(u_train.shape[0], u_train.shape[1])
    v = v_train + noise * np.std(v_train) * np.random.randn(v_train.shape[0], v_train.shape[1])

    model = PhysicsInformedNN(X_u_train, u_train, v_train, layers, lb, ub)
    model.train(42200)

    lambda_1_value_noisy = model.sess.run(model.lambda_1)
    lambda_2_value_noisy = model.sess.run(model.lambda_2)

    error_lambda_1_noisy = np.abs(lambda_1_value_noisy - 0.001) / 0.001 * 100
    error_lambda_2_noisy = np.abs(lambda_2_value_noisy - 0.03) / 0.03 * 100

    print('Error l1: %.5f%%' % (error_lambda_1_noisy))
    print('Error l2: %.5f%%' % (error_lambda_2_noisy))

    #####################################################################
    ########################### 0.05Noisy Data ###############################
    ######################################################################
    noise = 0.05
    u = u_train + noise * np.std(u_train) * np.random.randn(u_train.shape[0], u_train.shape[1])
    v = v_train + noise * np.std(v_train) * np.random.randn(v_train.shape[0], v_train.shape[1])

    model = PhysicsInformedNN(X_u_train, u_train, v_train, layers, lb, ub)
    model.train(6460)

    lambda_1_value_5noisy = model.sess.run(model.lambda_1)
    lambda_2_value_5noisy = model.sess.run(model.lambda_2)

    error_lambda_1_5noisy = np.abs(lambda_1_value_5noisy - 0.001) / 0.001 * 100
    error_lambda_2_5noisy = np.abs(lambda_2_value_5noisy - 0.03) / 0.03 * 100

    print('Error l1: %.5f%%' % (error_lambda_1_5noisy))
    print('Error l2: %.5f%%' % (error_lambda_2_5noisy))

    #####################################################################
    ########################### 0.1Noisy Data ###############################
    ######################################################################
    # noise = 0.1
    # u = u_train + noise * np.std(u_train) * np.random.randn(u_train.shape[0], u_train.shape[1])
    # v = v_train + noise * np.std(v_train) * np.random.randn(v_train.shape[0], v_train.shape[1])
    #
    # model = PhysicsInformedNN(X_u_train, u_train, v_train, layers, lb, ub)
    # model.train(8000)
    #
    # lambda_1_value_10noisy = model.sess.run(model.lambda_1)
    # lambda_2_value_10noisy = model.sess.run(model.lambda_2)
    #
    # error_lambda_1_10noisy = np.abs(lambda_1_value_10noisy - 0.001) / 0.001 * 100
    # error_lambda_2_10noisy = np.abs(lambda_2_value_10noisy - 0.03) / 0.03 * 100

    # print('Error l1: %.5f%%' % (error_lambda_1))
    # print('Error l2: %.5f%%' % (error_lambda_2))
    print('Error l1_1: %.5f%%' % (error_lambda_1_noisy))
    print('Error l2_1: %.5f%%' % (error_lambda_2_noisy))
    print('Error l1_5: %.5f%%' % (error_lambda_1_5noisy))
    print('Error l2_5: %.5f%%' % (error_lambda_2_5noisy))
    # print('Error l1_10: %.5f%%' % (error_lambda_1_10noisy))
    # print('Error l2_10: %.5f%%' % (error_lambda_2_10noisy))

    # print('l1: %.5f%%' % (lambda_1_value))
    # print('l2: %.5f%%' % (lambda_2_value))
    print('l1: %.5f%%' % (lambda_1_value_noisy))
    print('l2: %.5f%%' % (lambda_2_value_noisy))
    print('l1: %.5f%%' % (lambda_1_value_5noisy))
    print('l2: %.5f%%' % (lambda_2_value_5noisy))
    # print('l1: %.5f%%' % (lambda_1_value_10noisy))
    # print('l2: %.5f%%' % (lambda_2_value_10noisy))

    ######################################################################
    ############################# Plotting ###############################
    ######################################################################

